<template>
  <!-- <Header /> -->
  <router-link to="/">Home</router-link>
  <router-link to="/about">About</router-link>
  <router-view></router-view>
</template>

<script>
// import Header from './components/Header';
export default {
  name: 'App',
  // components: {
  //   Header
  // }
}
</script>

<style>
  @import "./assets/reset.css";
</style>


