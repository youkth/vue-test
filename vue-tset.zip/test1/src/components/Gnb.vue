<template>
    <ul>
        <li
        class="box"
        :style="{width: liWidth +'px', height: liHeight +'px'}"
        :class="[color]"
        >
        11111
        </li>
        <li>2</li>
        <li>3</li>
    </ul>

    <ul>
        <li class="item" v-for="(item, index) in items" :key="{index}">
            <a :href="item.link" target="_blank">
                <p><img :src="item.img" alt=""></p>
                <span>제목 : {{ item.name }}</span>
                <span v-if="item.isUpdate">N</span>
            </a>
        </li>
    </ul>
</template>

<script>
    export default {
        props:{
            color:{type:String, default:''},
            items:{type:Array, default:()=>[]}
        },
        data(){
            return {
                liWidth:40,
                liHeight:40
            }
        },
        methods:{

        }
    }
</script>

<style scoped>
    li {border: 1px solid red;}
    li.blue {
        background: blue;
    }
</style>